package com.example.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreSalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
